import threading


class ReadWriteLock:
    def __init__(self):
        self._lock = threading.Lock()  # 保护共享资源的锁
        self._read_cond = threading.Condition(self._lock)  # 读条件变量
        self._write_cond = threading.Condition(self._lock)  # 写条件变量
        self._readers = 0  # 当前读操作的数量
        self._writers_waiting = 0  # 等待的写操作数量
        self._writing = False  # 是否有写操作正在进行

    def acquire_read(self):
        """获取读锁"""
        with self._lock:
            while self._writers_waiting > 0 or self._writing:
                # 如果有写操作在等待或进行，读操作需要等待
                self._read_cond.wait()
            self._readers += 1

    def release_read(self):
        """释放读锁"""
        with self._lock:
            self._readers -= 1
            if self._readers == 0:
                # 如果没有读操作了，唤醒一个写操作
                self._write_cond.notify()

    def acquire_write(self):
        """获取写锁"""
        with self._lock:
            self._writers_waiting += 1
            while self._readers > 0 or self._writing:
                # 如果有读操作或写操作在进行，写操作需要等待
                self._write_cond.wait()
            self._writers_waiting -= 1
            self._writing = True

    def release_write(self):
        """释放写锁"""
        with self._lock:
            self._writing = False
            if self._writers_waiting > 0:
                # 优先唤醒写操作
                self._write_cond.notify()
            else:
                # 如果没有写操作在等待，唤醒所有读操作
                self._read_cond.notify_all()

    # 支持 with 语句的上下文管理器
    class ReadLockContext:
        def __init__(self, rw_lock):
            self.rw_lock = rw_lock

        def __enter__(self):
            self.rw_lock.acquire_read()
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.rw_lock.release_read()
            return False

    class WriteLockContext:
        def __init__(self, rw_lock):
            self.rw_lock = rw_lock

        def __enter__(self):
            self.rw_lock.acquire_write()
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.rw_lock.release_write()
            return False

    def read_lock(self):
        """返回一个读锁的上下文管理器"""
        return self.ReadLockContext(self)

    def write_lock(self):
        """返回一个写锁的上下文管理器"""
        return self.WriteLockContext(self)


# 示例用法
if __name__ == "__main__":
    import time

    rw_lock = ReadWriteLock()

    print_lock = threading.Lock()

    def safe_print(*args, **kwargs):
        with print_lock:
            print(*args, **kwargs)

    def reader():
        with rw_lock.read_lock():
            safe_print(f"Reader {threading.get_ident()} is reading")
            time.sleep(1)

    def writer():
        with rw_lock.write_lock():
            safe_print(f"Writer {threading.get_ident()} is writing")
            time.sleep(1)

    # 创建多个读线程和写线程
    threads = []
    for i in range(5):
        t = threading.Thread(target=reader)
        threads.append(t)
        t.start()

    for i in range(2):
        t = threading.Thread(target=writer)
        threads.append(t)
        t.start()

    for i in range(5):
        t = threading.Thread(target=reader)
        threads.append(t)
        t.start()
        t = threading.Thread(target=writer)
        threads.append(t)
        t.start()
    # 等待所有线程完成
    for t in threads:
        t.join()
